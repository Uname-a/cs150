#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scanner.h"
#include "support.h"

   int
   main(int argc,char **argv)
       {
       int dicount;
       int msgcount;
       int i;
       char ***dic;
       int * finalDic;
       int * finalMsg;
      
       char **msg;
       if (argc != 3)
            {
            printf("need two arguments!\n");
            exit(1);
            }
        dicount = countDic(argv[1]);
        //printf("%d\n",dicount);
        dic = readTable(argv[1],finalDic);
       // printTable(dic,dicount);
        



        msgcount = countTokens(argv[2]);

        //printf("%d\n",msgcount);
        

        msg = readMsg(argv[2],finalMsg);
        //printf("%s\n", msg[msgcount-1]);

        //printMsg(msg,msgcount);
        translate(msg,dic,msgcount,dicount);
        
       return 0;
       }