#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scanner.h"
int  countDic(char *);
int  countTokens(char *);
char *** 
    readTable(char *fileName,int *finalDic);
    char **
    readRecord(FILE *fp)           ;

void
    	printTable(char ***table,int size);
    	void
    	printMsg(char **table,int size);
char **
    readMsg(char *fileName,int *finalMsg);

void translate(char **Msg,char ***Dic,int msgcount, int dicount);