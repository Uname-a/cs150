#include <stdio.h>
#include <stdlib.h> 
#include <string.h>    //for exit
#include "scanner.h"

int 
    countDic(char *fileName)
   {
        FILE *in = fopen(fileName,"r");       //check for failed open omitted
            //check for failed open omitted
        int  count = 0;
        char *line;
        char *token;
        token = readToken(in);
        line = readString(in);        //readLine is a scanner module function
        while (!feof(in))
            {
            ++count;
            //printf("%s ",token);
            //printf("%s\n",line );
            //fprintf(out,"%s\n",line);
            free(line); 
            free(token);
            token = readToken(in)  ;          //we're done with line, so free it
            line = readString(in);
            }

        //always close your files
        fclose(in);
        

        return count;
        }
int 
    countTokens(char *fileName)
        {
        FILE *fp;
        char *token;
        int count = 0;
        
        fp = fopen(fileName,"r");
        if (fp == 0)
            {
            fprintf(stderr,"file %s could not be opened for reading\n",fileName);
            exit(1);
            }

        // output one token per line
        token = readToken(fp);
        //printf("%s\n",token);
        //count ++;
        while (!feof(fp))
            {
            
            ++count;
            free(token);
            token = readToken(fp);
            //printf("%s\n",token);
            }

        // always close your open files when finished!!
        fclose(fp);

        return count ;
        }
char **
    readRecord(FILE *fp)                // we pass the file pointer in
        {
        char *one,*two;
        char **record;
        
        one = readToken(fp);           //name is a string, not a token

        if (feof(fp)) { return 0; }      // no record, return null

        two = readString(fp);
        

        //make an empty record
        record = allocate(sizeof(char *) * 2);  //there are four fields

        //fill the record
        record[0] = one;
        record[1] = two;

        return record;
        }

char *** 
    readTable(char *fileName,int *finalDic)
        {
        FILE *fp;
        int count;
        int size = 10;                  //initial size of destination array
        char **record;
        char ***table;

        fp = fopen(fileName,"r");     //check for failed open omitted

        //allocate the destination array
        table = allocate(sizeof(char **) * size);

        count = 0;
        record = readRecord(fp);
        while (!feof(fp))
            {
            if (count == size)              //array is full!
                {
                // grow the array by doubling its size
                size = size * 2;
                table = reallocate(table,sizeof(char **) * size);
                //now there is enough room
                }
            table[count] = record;           //DO NOT FREE THE RECORD!
            ++count;
            record = readRecord(fp);
            }
        fclose(fp);

        //shrink the array to 'count' number of elements
        table = reallocate(table,sizeof(char **) * count);

        //count holds the number of items, store it in *finalSize
       // *finalDic = count;
        return table;
        }




//for debugging perposes
    void
    	printTable(char ***table,int size)
    	{
    		int i;
    		for (i = 0; i < size; ++i)
            {
            printf("%s\t",table[i][0] );
            printf("%s\t\n",table[i][1] );
            }
    	}
void
    	printMsg(char **msg,int size)
    	{
    		int i;
    		for (i = 0; i < size; ++i)
            {
            printf("%s\t",msg[i] );
            
            }
            printf("\n");
    	}



 char **
    readMsg(char *fileName,int *finalMsg)
        {
        FILE *fp = fopen(fileName,"r");     //check for failed open omitted
        int size = 10;                      //initial size of destination array
        char *token;
        int count;

        //allocate the destination array
        //char ** is a pointer to an array of strings (tokens are strings)
        char **items = allocate(sizeof(char *) * size);

        count = 0;
        token = readToken(fp);

        while (!feof(fp))
            {
            if (count == size)              //array is full!
                {
                // grow the array by doubling its size
                size = size * 2;
                items = reallocate(items,sizeof(char *) * size);
                //now there is enough room
                }
            items[count] = token;        //DO NOT FREE THE TOKEN!
            ++count;
            token = readToken(fp);

            }
        fclose(fp);

        //shrink the array to 'count' number of elements
        items = reallocate(items,sizeof(char *) * count);

        //count holds the number of items, store it in *finalSize
        //finalMsg = count;
        return items;
        }


void translate(char **Msg,char ***Dic,int msgcount,int dicount)
{
	int i;
	for(i=0;i < msgcount; i++)
	{
		int j;
		int yes = 0;
		for(j=0;j < dicount;j++)
		{
			if (strcmp(Msg[i],Dic[j][0]) == 0)
			{
				printf("%s ",Dic[j][1]);
				yes = 1;
			}
			
			else
			{
				yes == 0;
			}
		}
		if (yes == 0)
		{
			printf("%s ",Msg[i]);
		}

	}
	printf("\n");
}